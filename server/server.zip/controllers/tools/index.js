const youtube = require("./youtube");
const info = require("./info");

module.exports = {
  ...youtube,
  ...info,
};

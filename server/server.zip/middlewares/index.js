const umum_mid = require("./umum");
const prehandler = require("./prehandler");

module.exports = {
  ...umum_mid,
  ...prehandler,
};

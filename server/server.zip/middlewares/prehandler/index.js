const validator_user = require("./validator.user");

module.exports = {
  ...validator_user,
};

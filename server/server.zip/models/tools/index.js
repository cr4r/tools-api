const YoutubeModel = require("./youtube.model");

module.exports = {
  ...YoutubeModel,
};

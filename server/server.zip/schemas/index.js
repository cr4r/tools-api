const user_schema = require("./user.schema");

module.exports = {
  ...user_schema,
};

const text = require("./text");
const auth = require("./auth");

module.exports = {
  ...text,
  ...auth,
};

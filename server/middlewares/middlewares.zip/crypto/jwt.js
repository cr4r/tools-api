const jwt = require("jsonwebtoken");
const ms = require("ms");
const root_path = process.env.ROOT_PATH;
const refresh_token_exp = process.env.REFRESH_TOKEN_EXPIRY;
const access_token_exp = process.env.ACCESS_TOKEN_EXPIRY;

const { User, HistoryLogin } = require(`${root_path}/models`);
const secret = process.env.JWT_SECRET; // pastikan variabel ini ada di .env kamu

function generateAccessToken(payload) {
  return jwt.sign(payload, access_token_exp, {
    expiresIn: access_token_exp,
  });
}

function generateRefreshToken(payload) {
  return jwt.sign(payload, refresh_token_exp, {
    expiresIn: refresh_token_exp,
  });
}

const verifyTokenAndRole = async (req, reply) => {
  try {
    const token = req.headers["x-auth-token"];
    if (!token)
      return reply
        .code(401)
        .send({ status: false, message: "Token tidak ditemukan" });

    const decoded = jwt.verify(token, secret);
    // Optional: validasi user masih aktif di database
    const user = await User.findById(decoded._id);
    if (!user)
      return reply
        .code(401)
        .send({ status: false, message: "User tidak ditemukan" });
    // Masukkan data user ke request untuk digunakan di controller berikutnya

    // Memeriksa role yang dibutuhkan (admin.user atau admin saja)
    const roles = req.requiredRole.split("."); // Memecah role, misalnya admin.user
    // Gabungkan pemeriksaan role admin dan user dalam satu kondisi
    if (
      (roles.includes("admin") && user.role !== "admin") ||
      (roles.includes("user") && user.role !== "user")
    ) {
      return reply.code(403).send({
        status: false,
        message:
          "Akses ditolak. Kamu tidak memiliki akses atau bukan data sendiri.",
      });
    }
    // Masukkan data user ke request untuk digunakan di controller berikutnya
    req.user = user;
  } catch (err) {
    console.error(err);
    return reply.code(403).send({
      status: false,
      error: err,
      message: "Token tidak valid atau kadaluarsa",
    });
  }
};

const expiryDateToken = (jenis) => {
  return jenis == "refresh"
    ? new Date(Date.now() + ms(refresh_token_exp))
    : new Date(Date.now() + ms(access_token_exp));
};

module.exports = {
  generateAccessToken,
  generateRefreshToken,
  verifyTokenAndRole,
  expiryDateToken,
};

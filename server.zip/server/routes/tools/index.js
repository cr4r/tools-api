const YoutubeRoutes = require("./youtube.routes.js");

module.exports = {
  ...YoutubeRoutes,
};
